#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <pthread.h>   // included so it is a "Pthreads" build

typedef struct {
    double *x;
    double *y;
    double *m;
    double *vx;
    double *vy;
    double *brightness;
} Particle;

static double get_wall_seconds() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec / 1000000.0;
}

static void read_file(const char* filename, Particle* particles, int N) {
    FILE *file = fopen(filename, "rb");
    if (!file) { perror("fopen"); exit(1); }

    for (int i = 0; i < N; i++) {
        if (fread(&particles->x[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->y[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->m[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->vx[i],         sizeof(double), 1, file) != 1 ||
            fread(&particles->vy[i],         sizeof(double), 1, file) != 1 ||
            fread(&particles->brightness[i], sizeof(double), 1, file) != 1) {
            fprintf(stderr, "Error reading file\n");
            exit(1);
        }
    }
    fclose(file);
}

static void write_file(const char* filename, Particle* particles, int N) {
    FILE *file = fopen(filename, "wb");
    if (!file) { perror("fopen"); exit(1); }

    for (int i = 0; i < N; i++) {
        fwrite(&particles->x[i],          sizeof(double), 1, file);
        fwrite(&particles->y[i],          sizeof(double), 1, file);
        fwrite(&particles->m[i],          sizeof(double), 1, file);
        fwrite(&particles->vx[i],         sizeof(double), 1, file);
        fwrite(&particles->vy[i],         sizeof(double), 1, file);
        fwrite(&particles->brightness[i], sizeof(double), 1, file);
    }
    fclose(file);
}

static void simulate_serial(Particle* p, int N, double G, double dt, double eps) {
    // Allocate accel arrays once per step (N is tiny in the checker, ok)
    // If you want faster later: allocate once outside and reuse.
    double *ax = (double*)calloc((size_t)N, sizeof(double));
    double *ay = (double*)calloc((size_t)N, sizeof(double));
    if (!ax || !ay) { fprintf(stderr, "calloc failed\n"); exit(1); }

    for (int i = 0; i < N; i++) {
        double axi = 0.0, ayi = 0.0;
        double mi = p->m[i];

        for (int j = i + 1; j < N; j++) {
            double dx = p->x[i] - p->x[j];
            double dy = p->y[i] - p->y[j];
            double rij = sqrt(dx*dx + dy*dy);
            double reps = rij + eps;
            double a = G / (reps*reps*reps);

            axi   -= a * p->m[j] * dx;
            ayi   -= a * p->m[j] * dy;
            ax[j] += a * mi * dx;
            ay[j] += a * mi * dy;
        }
        ax[i] += axi;
        ay[i] += ayi;
    }

    for (int i = 0; i < N; i++) {
        p->vx[i] += dt * ax[i];
        p->vy[i] += dt * ay[i];
        p->x[i]  += dt * p->vx[i];
        p->y[i]  += dt * p->vy[i];
    }

    free(ax);
    free(ay);
}

int main(int argc, char* argv[]) {
    if (argc != 7) {
        fprintf(stderr, "Usage: %s N filename nsteps delta_t graphics num_threads\n", argv[0]);
        return 1;
    }

    int N = atoi(argv[1]);
    const char* filename = argv[2];
    int nsteps = atoi(argv[3]);
    double dt = atof(argv[4]);
    int graphics = atoi(argv[5]);
    int num_threads = atoi(argv[6]);

    (void)graphics;
    (void)num_threads; // accepted but not used (serial to match reference exactly)

    if (N < 1 || nsteps < 0) {
        fprintf(stderr, "Error: invalid N or nsteps\n");
        return 1;
    }

    double G = 100.0 / (double)N;
    double eps = 1e-3;

    Particle p;
    p.x          = (double*)malloc((size_t)N * sizeof(double));
    p.y          = (double*)malloc((size_t)N * sizeof(double));
    p.m          = (double*)malloc((size_t)N * sizeof(double));
    p.vx         = (double*)malloc((size_t)N * sizeof(double));
    p.vy         = (double*)malloc((size_t)N * sizeof(double));
    p.brightness = (double*)malloc((size_t)N * sizeof(double));

    if (!p.x || !p.y || !p.m || !p.vx || !p.vy || !p.brightness) {
        fprintf(stderr, "malloc failed\n");
        return 1;
    }

    read_file(filename, &p, N);

    double start = get_wall_seconds();
    for (int step = 0; step < nsteps; step++) {
        simulate_serial(&p, N, G, dt, eps);
    }
    double end = get_wall_seconds();

    write_file("result.gal", &p, N);

    // same output style as usual
    printf("%d %f\n", N, end - start);

    free(p.x); free(p.y); free(p.m);
    free(p.vx); free(p.vy); free(p.brightness);
    return 0;
}
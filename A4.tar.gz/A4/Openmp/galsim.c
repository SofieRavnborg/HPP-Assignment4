#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#ifdef _OPENMP
#include <omp.h>
#endif
#include <string.h> // memset

typedef struct {
    int N;
    int T;             // number of threads used for force
    double *ax;        // size N
    double *ay;        // size N
    double *ax_priv;   // size T*N, contiguous
    double *ay_priv;   // size T*N, contiguous
} ForceWorkspace;

typedef struct {
    double * restrict x;
    double * restrict y;
    double * restrict m;
    double * restrict vx;
    double * restrict vy;
    double * restrict brightness;
} Particle;




static ForceWorkspace* ws_create(int N, int T) {
    ForceWorkspace* ws = (ForceWorkspace*)malloc(sizeof(ForceWorkspace));
    ws->N = N;
    ws->T = T;
    ws->ax = (double*)malloc((size_t)N * sizeof(double));
    ws->ay = (double*)malloc((size_t)N * sizeof(double));
    ws->ax_priv = (double*)malloc((size_t)T * (size_t)N * sizeof(double));
    ws->ay_priv = (double*)malloc((size_t)T * (size_t)N * sizeof(double));
    if (!ws->ax || !ws->ay || !ws->ax_priv || !ws->ay_priv) {
        fprintf(stderr, "malloc failed\n");
        exit(1);
    }
    return ws;
}

static void ws_free(ForceWorkspace* ws) {
    if (!ws) return;
    free(ws->ax);
    free(ws->ay);
    free(ws->ax_priv);
    free(ws->ay_priv);
    free(ws);
}

static double get_wall_seconds() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec + (double)tv.tv_usec / 1000000.0;
}

void read_file(const char* filename, Particle* particles, int N) {
    FILE *file = fopen(filename, "rb");
    if (!file) { perror("fopen"); exit(1); }

    for (int i = 0; i < N; i++) {
        if (fread(&particles->x[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->y[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->m[i],          sizeof(double), 1, file) != 1 ||
            fread(&particles->vx[i],         sizeof(double), 1, file) != 1 ||
            fread(&particles->vy[i],         sizeof(double), 1, file) != 1 ||
            fread(&particles->brightness[i], sizeof(double), 1, file) != 1) {
            fprintf(stderr, "Error reading file\n");
            exit(1);
        }
    }
    fclose(file);
}

void write_file(const char* filename, Particle* particles, int N) {
    FILE *file = fopen(filename, "wb");
    if (!file) { perror("fopen"); exit(1); }

    for (int i = 0; i < N; i++) {
        fwrite(&particles->x[i],          sizeof(double), 1, file);
        fwrite(&particles->y[i],          sizeof(double), 1, file);
        fwrite(&particles->m[i],          sizeof(double), 1, file);
        fwrite(&particles->vx[i],         sizeof(double), 1, file);
        fwrite(&particles->vy[i],         sizeof(double), 1, file);
        fwrite(&particles->brightness[i], sizeof(double), 1, file);
    }
    fclose(file);
}

void simulate_profiled_ws(Particle* __restrict__ particles, int N,
                          double G, double dt, double eps,
                          ForceWorkspace* ws,
                          double *t_force, double *t_update)
{
    double t0, t1;

    // ---- FORCE ----
    t0 = get_wall_seconds();

#ifdef _OPENMP
#pragma omp parallel
#endif
    {
#ifdef _OPENMP
        int tid = omp_get_thread_num();
#else
        int tid = 0;
#endif
        double* lax = ws->ax_priv + (size_t)tid * (size_t)N;
        double* lay = ws->ay_priv + (size_t)tid * (size_t)N;

        // zero this thread's private arrays
        memset(lax, 0, (size_t)N * sizeof(double));
        memset(lay, 0, (size_t)N * sizeof(double));

#ifdef _OPENMP
#pragma omp for schedule(guided)
#endif
        for (int i = 0; i < N; i++) {
            double axi = 0.0, ayi = 0.0;
            const double xi = particles->x[i];
            const double yi = particles->y[i];
            const double mi = particles->m[i];

            for (int j = i + 1; j < N; j++) {
                double dx = xi - particles->x[j];
                double dy = yi - particles->y[j];

                // standard softening: r^2 + eps^2
                double r2   = dx*dx + dy*dy + eps*eps;
                double invr = 1.0 / sqrt(r2);
                double a    = G * invr * invr * invr;

                axi -= a * particles->m[j] * dx;
                ayi -= a * particles->m[j] * dy;

                lax[j] += a * mi * dx;
                lay[j] += a * mi * dy;
            }

            lax[i] += axi;
            lay[i] += ayi;
        }
    } // <-- VIKTIG: stänger parallel-blocket

    // ---- REDUCE (cachevänligare ordning) ----

// ---- REDUCE (en parallel for över k) ----
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
for (int k = 0; k < N; k++) {
    double sx = 0.0, sy = 0.0;
    for (int t = 0; t < ws->T; t++) {
        sx += ws->ax_priv[(size_t)t * (size_t)N + (size_t)k];
        sy += ws->ay_priv[(size_t)t * (size_t)N + (size_t)k];
    }
    ws->ax[k] = sx;
    ws->ay[k] = sy;
}// ---- REDUCE (en parallel for över k) ----
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
for (int k = 0; k < N; k++) {
    double sx = 0.0, sy = 0.0;
    for (int t = 0; t < ws->T; t++) {
        sx += ws->ax_priv[(size_t)t * (size_t)N + (size_t)k];
        sy += ws->ay_priv[(size_t)t * (size_t)N + (size_t)k];
    }
    ws->ax[k] = sx;
    ws->ay[k] = sy;
}

// #ifdef _OPENMP
// #pragma omp parallel for schedule(static)
// #endif
//     for (int k = 0; k < N; k++) { ws->ax[k] = 0.0; ws->ay[k] = 0.0; }

//     for (int t = 0; t < ws->T; t++) {
//         double* ax_t = ws->ax_priv + (size_t)t * (size_t)N;
//         double* ay_t = ws->ay_priv + (size_t)t * (size_t)N;

// #ifdef _OPENMP
// #pragma omp parallel for schedule(static)
// #endif
//         for (int k = 0; k < N; k++) {
//             ws->ax[k] += ax_t[k];
//             ws->ay[k] += ay_t[k];
//         }
//     }

    t1 = get_wall_seconds();
    *t_force += (t1 - t0);

    // ---- UPDATE ----
    t0 = get_wall_seconds();

#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < N; i++) {
        particles->vx[i] += dt * ws->ax[i];
        particles->vy[i] += dt * ws->ay[i];
        particles->x[i]  += dt * particles->vx[i];
        particles->y[i]  += dt * particles->vy[i];
    }

    t1 = get_wall_seconds();
    *t_update += (t1 - t0);
}

int main(int argc, char* argv[]) {
    if (argc != 7) {
        fprintf(stderr, "Usage: %s N filename nsteps delta_t graphics num_threads\n", argv[0]);
        return 1;
    }

    int N = atoi(argv[1]);
    const char* filename = argv[2];
    int nsteps = atoi(argv[3]);
    double dt = atof(argv[4]);
    int graphics = atoi(argv[5]);
    int num_threads = atoi(argv[6]);

    if (graphics) {
        printf("Graphics enabled (should be OFF when timing)\n");
    }

    double G = 100.0 / N;
    double eps = 1e-3;

    Particle particles;
    particles.x          = malloc((size_t)N * sizeof(double));
    particles.y          = malloc((size_t)N * sizeof(double));
    particles.m          = malloc((size_t)N * sizeof(double));
    particles.vx         = malloc((size_t)N * sizeof(double));
    particles.vy         = malloc((size_t)N * sizeof(double));
    particles.brightness = malloc((size_t)N * sizeof(double));

    read_file(filename, &particles, N);

    double t_alloc = 0, t_force = 0, t_update = 0, t_free = 0;

#ifdef _OPENMP
    omp_set_dynamic(0);
    omp_set_num_threads(num_threads);
    int T = omp_get_max_threads();
#else
    int T = 1;
#endif

    double t0 = get_wall_seconds();
    ForceWorkspace* ws = ws_create(N, T);
    double t1 = get_wall_seconds();
    t_alloc += (t1 - t0);

    double start = get_wall_seconds();
    for (int step = 0; step < nsteps; step++) {
        simulate_profiled_ws(&particles, N, G, dt, eps, ws, &t_force, &t_update);
    }
    double end = get_wall_seconds();

    t0 = get_wall_seconds();
    ws_free(ws);
    t1 = get_wall_seconds();
    t_free += (t1 - t0);

    write_file("result.gal", &particles, N);

    printf("%d %f\n", N, end - start);
    printf("Total:  %f s\n", end - start);
    printf("alloc:  %f s\n", t_alloc);
    printf("force:  %f s\n", t_force);
    printf("update: %f s\n", t_update);
    printf("free:   %f s\n", t_free);

    free(particles.x); free(particles.y); free(particles.m);
    free(particles.vx); free(particles.vy); free(particles.brightness);
    return 0;
}
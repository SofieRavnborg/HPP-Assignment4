#include <stdio.h>
#include <stdlib.h>
int main(int argc, char *argv[]) {

    
    if (argc != 2) {
        printf("Usage: %s <number_of_rows>\n", argv[0]);
        return 1;
    }

    int n = atoi(argv[1]);

    if (n <= 0) {
        printf("Number of rows must be positive\n");
        return 1;
    }

    int **matrix;

    // allocate rows
    matrix = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++)
        matrix[i] = (int *)malloc(n * sizeof(int));

    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++) {
            if (j<=i){
                 if (j==0){
                    matrix[i][j] = 1;
                }
                else if (i==j){
                    matrix[i][j] = 1;
                }
                else {
                    matrix[i][j] = matrix[i-1][j]+matrix[i-1][j-1];
            }
    }
    }
}
    for (int i = 0; i < n; i++) {
        for (int j = 0; j <= i; j++){
            printf("%d ", matrix[i][j]);
	}
        printf("\n");
    }





    for (int i = 0; i < n; i++)
        free(matrix[i]);
    free(matrix);
    return 0;
}

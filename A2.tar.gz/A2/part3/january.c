#include <stdio.h>
#include <stdlib.h>

typedef struct node {
    int ID;                 // day/index
    double min_temp;
    double max_temp;
    struct node *next;
} node_t;

void A(node_t **head, int index, double min, double max)
{
    node_t *prev = NULL;
    node_t *current = *head;

    // gå fram tills current->ID >= index eller slut
    while (current != NULL && current->ID < index) {
        prev = current;
        current = current->next;
    }

    // replace om finns
    if (current != NULL && current->ID == index) {
        current->min_temp = min;
        current->max_temp = max;
        return;
    }

    // annars insert ny nod
    node_t *new_node = malloc(sizeof(*new_node));
    if (!new_node) {
        perror("malloc");
        exit(1);
    }

    new_node->ID = index;
    new_node->min_temp = min;
    new_node->max_temp = max;

    // insert först
    if (prev == NULL) {
        new_node->next = *head;
        *head = new_node;
    } else { // insert i mitten/slut
        new_node->next = current;
        prev->next = new_node;
    }
}

void D(node_t **head, int index)
{
    node_t *prev = NULL;
    node_t *current = *head;

    while (current != NULL && current->ID != index) {
        prev = current;
        current = current->next;
    }

    if (current == NULL) {
        // tyst om index inte finns
        return;
    }

    if (prev == NULL) {
        *head = current->next;      // ta bort första
    } else {
        prev->next = current->next; // ta bort mitten/slut
    }

    free(current);
}

void P(node_t *head)
{
    if (head == NULL) {
        printf("List is empty\n");
        return;
    }

    node_t *current = head;
    while (current != NULL) {
        printf("Day %d  Min %.2f  Max %.2f\n",
               current->ID, current->min_temp, current->max_temp);
        current = current->next;
    }
}

void free_list(node_t **head)
{
    node_t *current = *head;
    while (current != NULL) {
        node_t *next = current->next;
        free(current);
        current = next;
    }
    *head = NULL;
}

int main(void)
{
    node_t *head = NULL;

    while (1) {
        printf("Enter command: ");

        char cmd;
        if (scanf(" %c", &cmd) != 1) break;

        if (cmd == 'A') {
            int index;
            double min, max;
            if (scanf("%d %lf %lf", &index, &min, &max) != 3) {
                printf("Bad A command\n");
                continue;
            }
            A(&head, index, min, max);
        }
        else if (cmd == 'D') {
            int index;
            if (scanf("%d", &index) != 1) {
                printf("Bad D command\n");
                continue;
            }
            D(&head, index);
        }
        else if (cmd == 'P') {
            P(head);
        }
        else if (cmd == 'Q') {
            break;
        }
        else {
            printf("Unknown command\n");
        }
    }

    free_list(&head);
    return 0;
}
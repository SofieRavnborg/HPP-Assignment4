#include <stdio.h>
#include <string.h>

int main() {

    FILE *fp = fopen("little_bin_file", "rb");


    if (!fp) {
        perror("fopen");
        return 1;
    }

    int i;
    double d;
    char c;
    float f;

    fread(&i, sizeof(int), 1, fp);
    fread(&d, sizeof(double), 1, fp);
    fread(&c, sizeof(char), 1, fp);
    fread(&f, sizeof(float), 1, fp);

    printf("int: %d\n", i);
    printf("double: %f\n", d);
    printf("char: %c\n", c);
    printf("float: %f\n", f);

    return 0 ;
}
